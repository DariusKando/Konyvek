function load(){
    fetch('http://localhost:5000/Konyv')
    .then(function(datak){return datak.json()})
    .then(function(data){
        document.getElementById('main').innerHTML="<h1>Könyvek</h1>"
        for(let i = 0; i < data.length; i++){
            if(i % 3 === 0){
                document.getElementById('main').innerHTML+= `<div class="row" id="row${Math.floor(i/3)}"></div>`
            }
            document.getElementById(`row${Math.floor(i/3)}`).innerHTML+=
            `
                <div class="col-4">
                    <div class="card owncard" style="width: 18rem;">
                    <p class="card-text">Könyv neve: ${data[i].nev}</p>
                    <h5 class="card-title">Kiadás éve: ${data[i].kiadasEve}</h5>
                    <p class="card-text">Könyv értékelése: ${data[i].ertekeles}</p>
                        <div class="card-body">
                            <a onclick="Single(${data[i].id})">
                                <img src="${data[i].kepneve}" class="card-img-top ownimg" alt="...">
                            </a>
                            <br>
                            <a onclick="Modify(${data[i].id})">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                                </svg>
                            </a>
                            <a onclick="Delete(${data[i].id})">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            `
        }
    })
}

function Single(id){
    fetch(`http://localhost:5000/Konyv/${id}`)
    .then(function(datak){return datak.json()})
    .then(function(data){
        document.getElementById(`main`).innerHTML =
        `
            <div class="card owncard" style="width: 18rem;">
            <p class="card-text">Könyv neve: ${data.nev}</p>
            <h5 class="card-title">Kiadás éve: ${data.kiadasEve}</h5>
            <p class="card-text">Könyv értékelése: ${data.ertekeles}</p>
                <div class="card-body">
                    <img src="${data.kepneve}" class="card-img-top ownimg" alt="...">
                    <br>
                    <a onclick="Modify(${data.id})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                            <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                        </svg>
                    </a>
                    <a onclick="Delete(${data.id})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                            <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                        </svg>
                    </a>
                    <a onclick="GoBack()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-backspace-fill" viewBox="0 0 16 16">
                            <path d="M15.683 3a2 2 0 0 0-2-2h-7.08a2 2 0 0 0-1.519.698L.241 7.35a1 1 0 0 0 0 1.302l4.843 5.65A2 2 0 0 0 6.603 15h7.08a2 2 0 0 0 2-2zM5.829 5.854a.5.5 0 1 1 .707-.708l2.147 2.147 2.146-2.147a.5.5 0 1 1 .707.708L9.39 8l2.146 2.146a.5.5 0 0 1-.707.708L8.683 8.707l-2.147 2.147a.5.5 0 0 1-.707-.708L7.976 8z"/>
                        </svg>
                    </a>
                </div>
            </div>
        `
    }
)}

function ShowAdd(id){
    document.getElementById('main').innerHTML=
    `
        <div id="addDiv">
            <label for="NewNev">Név:</label>
            <input type="text" id="NewNev">
                <br>
            <label for="NewKiadasEve">Kiadás éve:</label>
            <input type="number" id="NewKiadasEve">
                <br>
            <label for="NewErtekeles">Értékelés:</label>
            <input type="number" id="NewErtekeles">
                <br>
            <label for="NewKepneve">Kép url:</label>
            <input type="text" id="NewKepneve">
                <br>
            <button id="addButton" onclick="Add(${id})">Hozzáadás</button>
        </div>
    `
}

function Add(id){
    let nev = document.getElementById('NewNev').value;
    let kiadasEve = document.getElementById('NewKiadasEve').value;
    let ertekeles = document.getElementById('NewErtekeles').value;
    let kepneve = document.getElementById('NewKepneve').value;
    if (!nev || !kiadasEve || !ertekeles || !kepneve) {
        console.error("Írjad befele a cuccot tesikém!");
        return;
    }
    if(id == null){
        let string=JSON.stringify({
            nev: nev,
            kiadasEve: kiadasEve,
            ertekeles: ertekeles,
            kepneve: kepneve
        });
        fetch('http://localhost:5000/Konyv',{method:'POST',body:string,headers:{'Content-Type':'application/json'}})
        .then(function(){
            load()
        });
    }else{
        let string=JSON.stringify({
            id: id,
            nev: nev,
            kiadasEve: kiadasEve,
            ertekeles: ertekeles,
            kepneve: kepneve
        });
        fetch(`http://localhost:5000/Konyv/${id}`,{method:'PUT',body:string,headers:{'Content-Type':'application/json'}})
        .then(function(){
            load()
        });
    }
}

function Modify(id){
    ShowAdd(id)
    fetch(`http://localhost:5000/Konyv/${id}`)
    .then(function(datak){return datak.json()})
    .then(function(data){
        document.getElementById(`NewNev`).value = data.nev
        document.getElementById(`NewKiadasEve`).value = data.kiadasEve
        document.getElementById(`NewErtekeles`).value = data.ertekeles
        document.getElementById(`NewKepneve`).value = data.kepneve
    })
}

function Delete(id){
    if(confirm("ARE YOU SURE ABOUT THAT?")) {
        fetch(`http://localhost:5000/Konyv/${id}`, {
            method: "DELETE",
            headers: {
              'Content-Type': 'application/json'
            }
        }).then(function() {
            load()
        })
    }
}

function GoBack(){
    load()
}

window.onload = function() {
    load()
}